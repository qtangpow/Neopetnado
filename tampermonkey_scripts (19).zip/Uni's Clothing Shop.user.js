// ==UserScript==
// @name         Uni's Clothing Shop
// @namespace    Uni's Clothing Shop Restocker
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.neopets.com/objects.phtml?type=shop&obj_type=4
// @match        http://www.neopets.com/objects.phtml?obj_type=4&type=shop
// @grant        none
// ==/UserScript==
	(function() {
	
	    var patterns = [], classes = [];
	
	    /*    The following define the classes of words.  If the first
	    character of the specification is "=", the match will be
	    case-sensitive, otherwise it will be case-insensitive.
	    The specification is a regular expression, and should
	    contain metacharacters to handle variant spellings and
	    plurals.  Any grouping within these patterns *must* be done
	    with a (?: ... ) specification to avoid messing up the
	    capture from the text string.
	
	    You may add additional categories as you wish, but be sure to
	    declare their rendering in the style definition below.  */
	
	    //    Rendering styles for our various word classes
	
	    addGlobalStyle('span.blue { background-color: #00CCFF; } ' +
	           'span.silver { background-color: #A4A4A4; } ' +
	           'span.gold { background-color: #FE9A2E; } ');
	
	    //    MSM "blue" words
	
	    defwords([
"3D Glasses",
"Aisha Space Suit",
"Alien Aisha Ears",
"Barefoot Sandals",
"Bejewelled",
"Bionic Cybunny Cranium Cover",
"Black and White Trendy Dress",
"Bori Detective Hat",
"Casual Ixi Trousers",
"Colourful Female Hissi Dancer Dress",
"Colourful Female Hissi Dancer Shoes",
"Cool Jetsam Jacket",
"Cozy Kau Hat",
"Curly Blonde Skeith Wig",
"Cybunny Ocean Warrior Cape",
"Cybunny Ocean Warrior Dress",
"Cybunny Ocean Warrior Shoes",
"Cybunny Ocean Warrior Wig",
"Daffodil Chomby Jacket",
"Daffodil Chomby Lipstick",
"Dapper Poogle Hat",
"Dapper Poogle Trousers",
"Dark Faerie Wings",
"Dark Korbat Hero Tail Armour",
"Dark Uni Cloak",
"Delightful Poogle Necklace",
"Demure Usul Skirt",
"Disco Aisha Shoes",
"Draik Archer Quiver",
"Draik Sorceress Belt and Tunic",
"Draik Sorceress Cloak",
"Draik Traveller Gloves",
"Draik Traveller Shirt and Jacket",
"Earth Faerie Wings",
"Elegant Draik Dress",
"Elegant Draik Necklace",
"Elegant JubJub Dress",
"Elegant Kacheek Warrior Dress",
"Elegant Kacheek Warrior Wig",
"Elegant Uni Shoes",
"Elegant Uni Top",
"Elephante Barbarian Armour",
"Elephante Barbarian Bracers",
"Elephante Bard Boots",
"Elephante Bard Mandolin",
"Elephante Bard Trousers",
"Evening Draik Dress",
"Evening Draik Jewellery",
"Eyrie Militia Coat",
"Faerie Queen Wings",
"Fance Top",
"Fancy Aisha Wig",
"Fancy Ruki Shoes",
"Fashionable Gelert Shoes",
"Fashionable Gelert Skirt",
"Feathered Belt",
"Ferocious Negg Suit",
"Flying Pteri Boots",
"Flying Pteri Trousers",
"Gelert Spy Jacket",
"Gentleman Ogrin Trousers",
"Gnorbu Cowboy Holster",
"Gold Glitter Shoes",
"Gothic Korbat Wig",
"Gothic Kougra Jacket",
"Gothic Kougra Shoes",
"Gothic Kougra Trousers",
"Gothic Kougra Wig",
"Green Grundo Flip Flops",
"Green Kougra Wig",
"Grundo Miner Overalls",
"Grundo Space Goggles",
"Highland Gelert Boots",
"Hissi Gentleman Jacket",
"Hissi Thief Hood",
"Holiday Cherry Dress",
"Ixi Bandit Belt",
"JubJub Detective Trench Coat",
"Jungle Aisha Hat",
"Kacheek Mage Wig and Crown",
"Koi Captain Trousers and Shoes",
"Kougra Altador Heroine Dress",
"Krawk Wizard Cloak",
"Krawk Wizard Hood",
"Krawk Wizard Shoes",
"Krawk Wizard Staff",
"Kyrii Hostess Dress",
"Kyrii Mage Cape",
"Kyrii Mage Robe",
"Kyrii Swordsman Boots and Trousers",
"Little Red Riding Hood Krawk Basket",
"Little Red Riding Hood Krawk Shoes",
"Lotus Xweetok Dress",
"Lotus Xweetok Wig",
"Lovely Bruce Shoes",
"Lovely Kacheek Wig",
"Lupe Hunter Trousers",
"Lupe Knight Bottom Armour",
"Lupe Knight Foot Armour",
"Lupe Knight Tail Armour",
"Lupe Vagabond Gauntlets",
"Lutari Gentleman Jacket",
"Lutari Gentleman Shoes",
"Lutari Gentleman Trousers",
"Lutari Rogue Armour",
"Maraquan Scaled Dress",
"Milk Maid Techo Wig",
"Mysterious Draik Gloves",
"Mysterious Draik Jacket",
"Mysterious Draik Mask",
"Mysterious Draik Shoes",
"Mysterious Draik Trousers",
"Nimmo Farmer Overalls",
"On the Go Cybunny Dress",
"On the Go Cybunny Makeup",
"Pink Flowered Kougra Dress",
"Poogle Pink Tiara",
"Poogle Tutu",
"Poogle Wizard Hat",
"Proper Lady Ogrin Gloves",
"Proper Lady Ogrin Shoes",
"Proper Peophin Lady Necklace",
"Proper Peophin Lady Wig",
"Pteri Postman Shoes",
"Punkish Short Dress",
"Purple Hissi Dress",
"Purple Krawk Cloak",
"Quiggle Adventurer Trousers",
"Rebellious Ogrin Shoes",
"Red Wocky Suit Trousers",
"Regal Warrior Dress",
"Retro Glasses",
"Sakhmet Aisha Dancer Costume",
"School Girl Plaid Skirt",
"Shoyru Artist Trousers",
"Shoyru Pink Aviator Trousers",
"Shoyru Pyjama Plushie",
"Shoyru Wizard Cloak",
"Shrouded Draik Shirt and Sash",
"Shrouded Draik Shoes",
"Shrouded Draik Trousers",
"Snowy Xweetok Collar",
"Space Gypsy Xweetok Dress",
"Spring Time Male Krawk Hat",
"Spring Time Male Krawk Shoes",
"Spring Time Male Krawk Trousers",
"Studded Leather Uni Helmet",
"Studded Leather Uni Shoes",
"Studded Leather Uni Top",
"Studded Leather Uni Trousers",
"Sunny Flotsam Sandals",
"Techo Fighting Robe",
"Traditional Shenkuu Hissi Chest Covering",
"Traditional Shenkuu Hissi Gloves",
"Trendy Aisha Hat and Wig",
"Trendy Aisha Scarf",
"Trendy Aisha Shirt and Trousers",
"Trendy JubJub Dress",
"Trendy JubJub Jacket",
"Trendy Korbat Gloves",
"Tuskaninny Ballet Shoes",
"Tuskaninny Boy Beach Trousers",
"Uni Knight Top Armour",
"Usul Red Winter Hat",
"Velvet Black Lipstick",
"Warrior Lupe Maiden Necklace",
"Warrior Lupe Maiden Shoes",
"Waterskiing Jetsam Trousers",
"Winter Ranger Kougra Jacket",
"Winter Ranger Kougra Trousers",
"Winter Zafara Parka",
"Xweetok Popstar Dress",
"YEAAAAAH Awesome Korbat Magnifying Glass",
"Zafara Altador Heroine Dress",

	                ],
	    "blue");
	
	    //    MSM "silver" words
	
	    defwords([
"Blue Bogie T-Shirt",
"Draik Archer Hat",
"Draik Archer Trousers",
"Elegant Draik Earrings",
"Elegant Draik Hat",
"Elegant Draik Slippers",
"I Love Tenna T-Shirt",
"I got taxed by the Tax Beast T-Shirt",
"Ixi Forest Cape",
"Kacheek Pyjama Cap",
"Kacheek Pyjama Gown",
"Krawk Wizard Beard",
"Little Hearts Dress",
"Little Red Riding Hood Cybunny Cape",
"Lovely Kacheek Dress",
"Lupe Knight Top Armour",
"On the Go Cybunny Wig",
"Pretty Spring Cybunny Dress",
"Rocket Shoyru Helmet",
"Scary Teeth Mask",
"School Girl Shoes",
"Shenkuu-Inspired Paper Parasol",
"Shoyru Pink Aviator Jacket",
"Snowy Xweetok Dress",
"Steel Nails",
"Uni Knight Helmet",
"Usul Ski Suit",
"Yellow Ramosan T-Shirt",


	         ],
	    "silver");
	    
	        //    MSM "gold" words
	    
	    defwords([
"Blue Khonsu T-Shirt",
"Bronze Dress",
"Charming Pink Draik Gown",
"Elegant Pink Draik Fan",
"Erisim T-Shirt",
"Folding Gold Crown",
"Hasee T-Shirt",
"I Love Buzzer T-Shirt",
"I Love Chezzoom T-Shirt",
"I Love Faerie Cadro T-Shirt",
"I Love Hornsby T-Shirt",
"I Love Kadoatie T-Shirt",
"I Love Khamette T-Shirt",
"I Love Lyins T-Shirt",
"I Love Scarabug T-Shirt",
"I Love Selket T-Shirt",
"I Love Splyke T-Shirt",
"I Love Spyder T-Shirt",
"I Love Wadjet T-Shirt",
"Illusen Dress",
"Krawk T-Shirt",
"Nomadic Warrior Tonu Dress",
"Nomadic Warrior Tonu Necklace",
"Pinceron T-Shirt",
"Pink Blooky T-Shirt",
"Pink Flosset T-Shirt",
"Pink Kadoatie T-Shirt",
"Pink Walein T-Shirt",
"Pompoms Gelert Hat",
"Traditional Shenkuu Hissi Hat",
"White Faux Fur Coat",
"Yellow Avabot T-Shirt",
"Yellow Buzzer T-Shirt",
"Yellow Kookith T-Shirt",
"Yellow Moltenore T-Shirt",
"Yellow Sunutek T-Shirt",
"Yellow Zebba T-Shirt",

	       
	         ],
	    "gold");
	
	    //    Add one or more words to the dictionary with a specified class
	
	    function defwords(words, which_class) {
	    for (var i = 0; i < words.length; i++) {
	        var w = words[i].replace(/^=/, "");
	        patterns.push(new RegExp("([^a-zA-Z])(" + w + ")([^a-zA-Z])",
	        words[i].match(/^=/) ? "g" : "gi"));
	        classes.push(which_class);
	    }
	    }
	
	    //    Quote HTML metacharacters in body text
	
	    function quoteHTML(s) {
	    s = s.replace(/&/g, "&amp;");
	    s = s.replace(/</g, "&lt;");
	    s = s.replace(/>/g, "&gt;");
	    return s;
	    }
	
	    //    Add one or more CSS style rules to the document
	
	    function addGlobalStyle(css) {
	    var head, style;
	    head = document.getElementsByTagName('head')[0];
	    if (!head) {
	        return;
	    }
	    style = document.createElement('style');
	    style.type = 'text/css';
	    style.innerHTML = css;
	    head.appendChild(style);
	    }
	
	    //    Apply highlighting replacements to a text sequence
	
	    var curpat;             // Hidden argument to repmatch()
	    var changes;            // Number of changes made by repmatch()
	
	    function repmatch(matched, before, word, after) {
	    changes++;
	    return before + '<span class="' + classes[curpat] + '">' + word + '</span>' + after;
	    }
	
	    function highlight(s) {
	    s = " " + s;
	    for (curpat = 0; curpat < patterns.length; curpat++) {
	        s = s.replace(patterns[curpat],
	            repmatch);
	    }
	    return s.substring(1);
	    }
	
	    //    We only modify HTML/XHTML documents
	    if (document.contentType &&
	        (!(document.contentType.match(/html/i)))) {
	        return;
	    }
	
	    // Highlight words in body copy
	
	    var textnodes = document.evaluate("//body//text()", document, null,
	        XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
	
	    for (var i = 0; i < textnodes.snapshotLength; i++) {
	    var node = textnodes.snapshotItem(i);
	    /* Test whether this text node appears within a
	       <style>, <script>, or <textarea> container.
	       If so, it is not actual body text and must
	       be left alone to avoid wrecking the page. */
	    if (node.parentNode.tagName != "STYLE" &&
	        node.parentNode.tagName != "TEXTAREA" &&
	        node.parentNode.tagName != "SCRIPT") {
	        /* Many documents have large numbers of empty text nodes.
	           By testing for them, we avoid running all of our
	           regular expressions over a target which they can't
	           possibly match. */
	        if (!(node.data.match(/^\s*$/))) {
	        var s = " " + node.data + " ";
	        changes = 0;
	        var d = highlight(quoteHTML(s));
	        if (changes > 0) {
	            var rep = document.createElement("span");
	            rep.innerHTML = d.substring(1, d.length - 1);
	            node.parentNode.replaceChild(rep, node);
	        }
	        }
	    }
	    }
	
	})();

(function() {
    'use strict';

    // Your code here...
})();