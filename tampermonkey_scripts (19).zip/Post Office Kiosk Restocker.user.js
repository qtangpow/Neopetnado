// ==UserScript==
// @name         Post Office Kiosk Restocker
// @namespace    Post Office Kiosk Restocker
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.neopets.com/objects.phtml?obj_type=58&type=shop
// @match        http://www.neopets.com/objects.phtml?type=shop&obj_type=58
// @grant        none
// ==/UserScript==
(function() {

    var patterns = [], classes = [];

    /*    The following define the classes of words.  If the first
    character of the specification is "=", the match will be
    case-sensitive, otherwise it will be case-insensitive.
    The specification is a regular expression, and should
    contain metacharacters to handle variant spellings and
    plurals.  Any grouping within these patterns *must* be done
    with a (?: ... ) specification to avoid messing up the
    capture from the text string.

    You may add additional categories as you wish, but be sure to
    declare their rendering in the style definition below.  */

    //    Rendering styles for our various word classes

    addGlobalStyle('span.blue { background-color: #D0D0FF; } ' +
           'span.silver { background-color: #A4A4A4; } ' +
           'span.gold { background-color: #FE9A2E; } ');

    //    MSM "blue" words

    defwords([
"Desert Paint Brush Stamp",
"Spyder Stamp",
"Garin To The Rescue Stamp",
"Zurroball Stamp",
"Hoban Stamp",
"Fountain Faerie Stamp",
"Jelly World Stamp",
"Sentient Headstones Stamp",
"Super Bright Rainbow Pool Stamp",
"Dr. Sloth Stamp",
"Shenkuu Mask Stamp",
"Christmas Scene Stamp",
"Snowager Stamp",
"Hot Dog Hero Stamp",
"Dorak Stamp",
"Jade Scorchstone Stamp",
"Rainbow Pool Stamp",
"Zyrolon Stamp",
"Evil Fuzzles Stamp",
"Fyora Faerie Doll Stamp",
"Lupe Shopkeeper Stamp",
"Thoughtful Linae Stamp",
"Charms Stamp",
"Astronomy Club Stamp",
"Lost Desert Scroll Stamp",
"Green Knight Stamp",
"Negg Faerie Stamp",
"Tangor Stamp",
"Meridell Castle Stamp",
"RIP Lucy Stamp",
"Ruler of the Five Seas Stamp",
"Finneus Stamp",
"Blumaroo Court Jester Stamp",
"Yes-Boy Ice Cream Stamp",
"The Revenge Stamp",
"Razul Stamp",
"Gargarox Isafuhlarg Stamp",
"Lava Monster Stamp",
"Orrin Stamp",
"Haunted Mansion Stamp",
"Meridell Heroes Stamp",
"Caylis Stamp",
"Rainbow Pteri Feather Stamp",
"The Krawken Stamp",

                ],
    "blue");

    //    MSM "silver" words

    defwords([
"Dark Qasala Stamp",
"Shumi Telescope Stamp",
"Commemorative Defenders Stamp #4",
"Darigan Citadel Stamp",
"Luperus Left Head Stamp",
"Mr. Krawley Stamp",
"Zombified Heroes Stamp",
"Altador Magic Stamp",
"Yellow Knight Stamp",
"Moltara Town Hall Stamp",
"The Academy Stamp",
"Luperus Right Head Stamp",
"Space Faerie Stamp",
"Biyako Stamp",
"Dark Faerie Stamp",
"Destruction of Faerieland Stamp",
"Scordrax Stamp",
"Shadow Gulch Stamp",
"Faerie Slorg Stamp",
"Talinia Stamp",
"Forgotten Shore Stamp",
"Lampwyck Stamp",
"Luperus Centre Head Stamp",
"Tomos Stamp",
"Capn Threelegs Stamp",
"Altador Travel Stamp",
"Dark Ilere Stamp",
"Lost City of Phorofor Stamp",
"Morris Stamp",
"Singed Tyrannian Volcano Stamp",
"The Sleeper Constellation Stamp",
"Zafara Double Agent Stamp",
"Northern Watch Tower Stamp",
"Anshu Fishing Stamp",
"Blugthak Stamp",
"Shenkuu Helmet Stamp",
"Von Roos Castle Stamp",
"Gors The Mighty Stamp",
"Nabile Stamp",
"The Cyodrakes Gaze Stamp",
"Battle Uni Stamp",
"Torakor Stamp",
"Fyoras Castle Stamp",
"Gold Mote Stamp",
"Cybunny on a Cycle Stamp",
"Mipsy Stamp",
"Anubits Stamp",
"Darigan Moehog Stamp",
"Grundo Warehouse Stamp",
"Tyrannian Victory Day Stamp",
"Lucky Coin Stamp",
"Guardian Of Spectral Magic Stamp",

        
         ],
    "silver");
    
        //    MSM "gold" words
    
    defwords([ 
"Igneots Cavern Stamp",
"Swordsmaster Talek Stamp",
"NeoQuest Hero Stamp",
"Aethia Stamp",
"Shiny Monoceraptor Stamp",
"Drackonack Stamp",
"Usuki Doll Stamp",
"Count Von Roo Stamp",
"Ramtor Stamp",
"Sword Of Apocalypse Stamp",
"Darkest Faerie Stamp",
"Meerca Spy Stamp",
"Nightsteed Stamp",
"Ready to Roll Stamp",
"Stone Stamp",
"Golden Dubloon Stamp",
"Quilin Stamp",
"Grimtooth Stamp",
"Rainbow Sticky Hand Stamp",
"Wise Gnorbu Stamp",
"Jacques Stamp",
"Misaligned Printer Stamp",
"Garin Stamp",
"Upside Down Island Acara Stamp",
"Inverted Space Faerie Stamp",
"Isca Stamp",
"Need a Better Printer Stamp",
"One Hundred Million Neopoint Stamp",
"Xantan Stamp",
"Nibbled Cooking Pot Stamp",
"The Three Stamp",
"Foil Food Shop Stamp",
"Jhudoras Cloud Stamp",
"Igneot Stamp",
"Double Printed Evil Fuzzle Stamp",
"Holographic Coltzans Shrine Stamp",
"Holographic Virtupets Stamp",
"Lord Kass Stamp",
"Geraptiku Stamp",
"King Jazan Stamp",
"Lab Ray Stamp",
"The Great Battle Stamp",
"Foil Slorg Stamp",
"Dark Battle Duck Stamp",
"Scuzzy Stamp",
"Terask Stamp",
"ARGH!!!! DONNA STAMP",
"Captain Scarblade Stamp",
"King Kelpbeard Stamp",
"Battle Slices Stamp",
"Bringer of Night Stamp",
"Count Von Roo Plushie Stamp",
"Court Dancer Stamp",
"Darigan Spectre Stamp",
"Hadrak Stamp",
"Holographic Magax Stamp",
"Jahbal Stamp",
"King Altador Stamp",
"Lady Frostbite Stamp",
"Misprint Meuka Stamp",
"Morguss Stamp",
"NeoQuest II Esophagor Stamp",
"NeoQuest Logo Stamp",
"Queen Fyora Stamp",
"Sasha Stamp",
"Shenkuu Stamp",
"Skeith Defender Stamp",
"Snowbunny Stamp",
"Sticky Snowflake Stamp",
"Virtupets Space Station Stamp",

       
         ],
    "gold");

    //    Add one or more words to the dictionary with a specified class

    function defwords(words, which_class) {
    for (var i = 0; i < words.length; i++) {
        var w = words[i].replace(/^=/, "");
        patterns.push(new RegExp("([^a-zA-Z])(" + w + ")([^a-zA-Z])",
        words[i].match(/^=/) ? "g" : "gi"));
        classes.push(which_class);
    }
    }

    //    Quote HTML metacharacters in body text

    function quoteHTML(s) {
    s = s.replace(/&/g, "&amp;");
    s = s.replace(/</g, "&lt;");
    s = s.replace(/>/g, "&gt;");
    return s;
    }

    //    Add one or more CSS style rules to the document

    function addGlobalStyle(css) {
    var head, style;
    head = document.getElementsByTagName('head')[0];
    if (!head) {
        return;
    }
    style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = css;
    head.appendChild(style);
    }

    //    Apply highlighting replacements to a text sequence

    var curpat;             // Hidden argument to repmatch()
    var changes;            // Number of changes made by repmatch()

    function repmatch(matched, before, word, after) {
    changes++;
    return before + '<span class="' + classes[curpat] + '">' + word + '</span>' + after;
    }

    function highlight(s) {
    s = " " + s;
    for (curpat = 0; curpat < patterns.length; curpat++) {
        s = s.replace(patterns[curpat],
            repmatch);
    }
    return s.substring(1);
    }

    //    We only modify HTML/XHTML documents
    if (document.contentType &&
        (!(document.contentType.match(/html/i)))) {
        return;
    }

    // Highlight words in body copy

    var textnodes = document.evaluate("//body//text()", document, null,
        XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);

    for (var i = 0; i < textnodes.snapshotLength; i++) {
    var node = textnodes.snapshotItem(i);
    /* Test whether this text node appears within a
       <style>, <script>, or <textarea> container.
       If so, it is not actual body text and must
       be left alone to avoid wrecking the page. */
    if (node.parentNode.tagName != "STYLE" &&
        node.parentNode.tagName != "TEXTAREA" &&
        node.parentNode.tagName != "SCRIPT") {
        /* Many documents have large numbers of empty text nodes.
           By testing for them, we avoid running all of our
           regular expressions over a target which they can't
           possibly match. */
        if (!(node.data.match(/^\s*$/))) {
        var s = " " + node.data + " ";
        changes = 0;
        var d = highlight(quoteHTML(s));
        if (changes > 0) {
            var rep = document.createElement("span");
            rep.innerHTML = d.substring(1, d.length - 1);
            node.parentNode.replaceChild(rep, node);
        }
        }
    }
    }

})();

(function() {
    'use strict';

    // Your code here...
})();