// ==UserScript==
// @name         Plushie Palace Restocker
// @namespace    Plushie Palace 
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.neopets.com/objects.phtml?type=shop&obj_type=98
// @match        http://www.neopets.com/objects.phtml?obj_type=98&type=shop
// @grant        none
// ==/UserScript==
(function() {

    var patterns = [], classes = [];

    /*    The following define the classes of words.  If the first
    character of the specification is "=", the match will be
    case-sensitive, otherwise it will be case-insensitive.
    The specification is a regular expression, and should
    contain metacharacters to handle variant spellings and
    plurals.  Any grouping within these patterns *must* be done
    with a (?: ... ) specification to avoid messing up the
    capture from the text string.

    You may add additional categories as you wish, but be sure to
    declare their rendering in the style definition below.  */

    //    Rendering styles for our various word classes

    addGlobalStyle('span.blue { background-color: #00CCFF; } ' +
           'span.silver { background-color: #A4A4A4; } ' +
           'span.gold { background-color: #FE9A2E; } ');

    //    MSM "blue" words

    defwords([
"Angel Chia Plushie",
"Angel Kiko Plushie",
"Angry Vira Plushie",
"Ariadne Plushie",
"Asparagus Chia Plushie",
"Baby Peophin Plushie",
"Baby Techo Plushie",
"Baby Xweetok Plushie",
"Blue Draik Plushie",
"Branch Plushie",
"Bruce Smuggler Plushie",
"Christmas JubJub Plushie",
"Cloud Kacheek Plushie",
"Darigan Gelert Plushie",
"Darigan Uni Plushie",
"Desert Wocky Plushie",
"Deviled Steak Plushie",
"Electric Fuzzle",
"Electric Ixi Plushie",
"Evil Twin Green Quiggle Plushie",
"Evil Twin Yellow Chia Plushie",
"Faerie Kougra Plushie",
"Faerie Xweetok Plushie",
"Fire JubJub Plushie",
"Galem Plushie",
"Galgarroth Plushie",
"Ghost Draik Plushie",
"Ghost Ixi Plushie",
"Giant Moehog Plushie",
"Golden Bori Plushie",
"Green Draik Plushie",
"Grey Chomby Plushie",
"Grimtooth Plushie",
"Hagan Plushie",
"Halloween Mynci Plushie",
"Halloween Nimmo Plushie",
"Handcrafted Fyora Plushie",
"Handcrafted Tomos Plushie",
"Happiness Faerie Plushie",
"Huggy Bear Plushie",
"Iron Golem Neoquest Plushie",
"Jake Plushie",
"Jhudora Plushie",
"Kanrik Plushie",
"Kentari Plushie",
"Knitted Chia Plushie",
"Lenny Smuggler Plushie",
"Magical Blue Kyrii Plushie",
"Magical Yellow Kyrii Plushie",
"Magma Tonu Plushie",
"Mipsy Plushie",
"Mumbo Pango Plushie",
"Mutant Kiko Plushie",
"Mutant Krawk Plushie",
"Mutant Techo Plushie",
"Negg Faerie Plushie",
"New Years Techo Plushie",
"Orange Gelert Plushie",
"Pink Draik Plushie",
"Pirate Moehog Plushie",
"Pirate Poogle Plushie",
"Plains Lupe Neoquest Plushie",
"Plushie Wocky Plushie",
"Purple Vandagyre Plushie",
"Rainbow Fuzzle",
"Rainbow Ruki Plushie",
"Rainbow Scorchio Plushie",
"Rock Golem Neoquest Plushie",
"Royal Boy Kougra Plushie",
"Royal Boy Usul Plushie",
"Royal Girl Kyrii Plushie",
"Scamander Plushie",
"Scoach Plushie",
"Shumi Plushie",
"Silver Kougra Plushie",
"Spider Grundo Plushie",
"Starry Koi Plushie",
"Strawberry JubJub Plushie",
"Striped Fuzzle",
"The Masked Intruder Plushie",
"Underwater Chef Plushie",
"Valentines Cybunny Plushie",
"Valentines Faellie Plushie",
"Valentines Hasee Plushie",
"Valentines Kacheek Plushie",
"Valentines Kadoatie Plushie",
"White Skeith Plushie",
"Woodland Uni Plushie",
"Yellow Draik Plushie",
"Zombie Slorg Plushie",
"Zombom Plushie",

                ],
    "blue");

    //    MSM "silver" words

    defwords([
"Advent Calendar Aisha Plushie",
"Agate Dervish Plushie",
"Anshu Plushie",
"Baby Cybunny Plushie",
"Baby Uni Plushie",
"Black Bearog Plushie",
"Bonju Plushie",
"Christmas Bruce Plushie",
"Darigan Flotsam Plushie",
"Darigan Krawk Plushie",
"Darigan Lupe Plushie",
"Denethrir Plushie",
"Desert Aisha Plushie",
"Desert Elephante Plushie",
"Desert Krawk Plushie",
"Disco Bruce Plushie",
"Drakonid Plushie",
"Edna Plushie",
"Electric Evil Fuzzle",
"Eye Candy Plushie",
"Faerie Draik Plushie",
"Faerie Meerca Plushie",
"Faerie Shoyru Plushie",
"Faerie Uni Plushie",
"Grey Lupe Neoquest Plushie",
"Grey Negg Plushie",
"Grey Wocky Plushie",
"Halloween Moehog Plushie",
"Halloween Poogle Plushie",
"Halloween Tonu Plushie",
"Handcrafted Illusen Plushie",
"Handcrafted Kanrik Plushie",
"Illusen Plushie",
"Insane Evil Fuzzle",
"Judge Hog Plushie",
"King Roo Plushie",
"Magical Cloud Lupe Plushie",
"Magical Desert Krawk Plushie",
"Magical Electric Lupe Plushie",
"Magical Fire Lupe Plushie",
"Magical Green Kyrii Plushie",
"Magical Pirate Krawk Plushie",
"Magical Red Buzz Plushie",
"Magical Red Krawk Plushie",
"Magical Silver Kougra Plushie",
"Magical Starry Lupe Plushie",
"Magical Yellow Cybunny Plushie",
"Manufacturing Error Faerie Plushie",
"Maraquan Ixi Plushie",
"Maraquan Techo Plushie",
"Masila Plushie",
"Mazzew Plushie",
"Mutant Usul Plushie",
"Plushie Ixi Plushie",
"Plushie Poogle Plushie",
"Rainbow JubJub Plushie",
"Rainbow Korbat Plushie",
"Rainbow Wocky Plushie",
"Roberta Plushie",
"Robo Grarrl Plushie",
"Rohane Plushie",
"Royal Boy Bruce Plushie",
"Royal Boy Ixi Plushie",
"Scorchio Auctioneer Plushie",
"Spotted Koi Plushie",
"Starry Uni Plushie",
"Stone Golem Neoquest Plushie",
"Striped Evil Fuzzle",
"Striped Lenny Plushie",
"Thunder Lizard Plushie",
"Tormund Plushie",
"Tylix Plushie",
"Un-Valentines Skeith Plushie",
"Valin Plushie",
"Velm Plushie",
"Young Sophie Plushie",
"Zafara Double Agent Plushie",

         ],
    "silver");
    
        //    MSM "gold" words
    
    defwords([
"Archmagus of Roo Plushie",
"Armin Plushie",
"Baby Bruce Plushie",
"Bat Thing Plushie",
"Black Wadjet Plushie",
"Blizzard Kougra Plushie",
"Blue Doglefox Plushie",
"Boraxis Plushie",
"Bowe Plushie",
"Brown Wadjet Plushie",
"Chaos Giant Plushie",
"Christmas Korbat Plushie",
"Chrysolite Dervish Plushie",
"Cloud Draik Plushie",
"Cloud Lenny Plushie",
"Darigan Acara Plushie",
"Darigan Eyrie Plushie",
"Darkest Faerie Plushie",
"Desert Cobrall Plushie",
"Desert Grarrl Plushie",
"Desert Ixi Plushie",
"Desert Lupe Plushie",
"Doctor Plushie",
"Dusk Kougra Plushie",
"Electro Lizard Plushie",
"Faerie Kacheek Plushie",
"Faerie Korbat Plushie",
"Faerie Lupe Plushie",
"Faerie Nimmo Plushie",
"Faleinn Plushie",
"Fire Eyrie Plushie",
"Fire Lizard Plushie",
"Fish Negg Plushie",
"Floppy Turtum Plushie",
"Frost Lizard Plushie",
"Frozen Lizard Plushie",
"Ghost Evil Fuzzle",
"Ghost Fuzzle",
"Giant Jeran Plushie",
"Gloom Kougra Plushie",
"Granite Dervish Plushie",
"Grey Kacheek Plushie",
"Grey Mynci Plushie",
"Grey Peophin Plushie",
"Guardian of Fire Magic Plushie",
"Halloween Blumaroo Plushie",
"Halloween Chia Plushie",
"Halloween Draik Plushie",
"Halloween JubJub Plushie",
"Hannah Plushie",
"Inferno Lizard Plushie",
"Island Peophin Plushie",
"Jahbal Plushie",
"Keeper Of Time Plushie",
"King Skarl Plushie",
"King Terask Plushie",
"Lazulite Dervish Plushie",
"Leirobas Plushie",
"Lightning Giant Plushie",
"Lightning Lizard Plushie",
"Lord Kass Plushie",
"MSPP Plushie",
"Magical Blue Cybunny Plushie",
"Magical Blue Flotsam Plushie",
"Magical Blue Kacheek Plushie",
"Magical Blue Kiko Plushie",
"Magical Blue Krawk Plushie",
"Magical Blue Nimmo Plushie",
"Magical Blue Shoyru Plushie",
"Magical Blue Tonu Plushie",
"Magical Blue Yurble Plushie",
"Magical Cloud Gelert Plushie",
"Magical Cloud Lenny Plushie",
"Magical Ghost Marshmallows Plushie",
"Magical Green Cybunny Plushie",
"Magical Green Flotsam Plushie",
"Magical Green Gelert Plushie",
"Magical Green Kiko Plushie",
"Magical Green Koi Plushie",
"Magical Green Krawk Plushie",
"Magical Green Tonu Plushie",
"Magical Green Wocky Plushie",
"Magical Green Yurble Plushie",
"Magical Purple Blumaroo Plushie",
"Magical Purple Koi Plushie",
"Magical Purple Zafara Plushie",
"Magical Rainbow Aisha Plushie",
"Magical Rainbow Blumaroo Plushie",
"Magical Rainbow Cybunny Plushie",
"Magical Red Blumaroo Plushie",
"Magical Red Cybunny Plushie",
"Magical Red Flotsam Plushie",
"Magical Red Gelert Plushie",
"Magical Red Grarrl Plushie",
"Magical Red Kiko Plushie",
"Magical Red Koi Plushie",
"Magical Red Kyrii Plushie",
"Magical Red Lenny Plushie",
"Magical Red Nimmo Plushie",
"Magical Red Skeith Plushie",
"Magical Red Tonu Plushie",
"Magical Red Usul Plushie",
"Magical Red Wocky Plushie",
"Magical Red Yurble Plushie",
"Magical Spotted Blumaroo Plushie",
"Magical Starry Kau Plushie",
"Magical Yellow Flotsam Plushie",
"Magical Yellow Kiko Plushie",
"Magical Yellow Lenny Plushie",
"Magical Yellow Nimmo Plushie",
"Magical Yellow Skeith Plushie",
"Magical Yellow Tonu Plushie",
"Magical Yellow Wocky Plushie",
"Magical Yellow Yurble Plushie",
"Mastermind Plushie",
"Melatite Dervish Plushie",
"Mist Kougra Plushie",
"Mokti Plushie",
"Monoceraptor Plushie",
"Mutant Blumaroo Plushie",
"Mutant Korbat Plushie",
"Mutant Shoyru Plushie",
"NeoQuest Hero Plushie",
"Neopian Times White Weewoo Plushie",
"Neoquest Gatekeeper Plushie",
"Nuria Plushie",
"Orange Draik Plushie",
"Pomanna Plushie",
"Rainbow Evil Fuzzle",
"Rainbow Grundo Plushie",
"Rainbow Tuskaninny Plushie",
"Rainbow Uni Plushie",
"Razul Plushie",
"Reject Blue Acara Plushie",
"Reject Gelert Plushie",
"Reject Green Acara Plushie",
"Reject Red Acara Plushie",
"Reject Yellow Acara Plushie",
"Rikti Plushie",
"Serpentine Dervish Plushie",
"Shadow Kougra Plushie",
"Shock Lizard Plushie",
"Shop Wizard Plushie",
"Sidney Plushie",
"Skunk Mynci Plushie",
"Sophie Plushie",
"Speckled Bruce Plushie",
"Speckled Nimmo Plushie",
"Spotted Gelert Plushie",
"Starry Draik Plushie",
"Steel Golem Neoquest Plushie",
"Striped Korbat Plushie",
"Swamp Lupe Neoquest Plushie",
"Taelia Plushie",
"Tax Beast Plushie",
"Two Rings Archmagus Plushie",
"Tyrannian Techo Plushie",
"White Draik Plushie",
"White Ixi Plushie",
"Wrawk the Merciless Plushie",


         ],
    "gold");

    //    Add one or more words to the dictionary with a specified class

    function defwords(words, which_class) {
    for (var i = 0; i < words.length; i++) {
        var w = words[i].replace(/^=/, "");
        patterns.push(new RegExp("([^a-zA-Z])(" + w + ")([^a-zA-Z])",
        words[i].match(/^=/) ? "g" : "gi"));
        classes.push(which_class);
    }
    }

    //    Quote HTML metacharacters in body text

    function quoteHTML(s) {
    s = s.replace(/&/g, "&amp;");
    s = s.replace(/</g, "&lt;");
    s = s.replace(/>/g, "&gt;");
    return s;
    }

    //    Add one or more CSS style rules to the document

    function addGlobalStyle(css) {
    var head, style;
    head = document.getElementsByTagName('head')[0];
    if (!head) {
        return;
    }
    style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = css;
    head.appendChild(style);
    }

    //    Apply highlighting replacements to a text sequence

    var curpat;             // Hidden argument to repmatch()
    var changes;            // Number of changes made by repmatch()

    function repmatch(matched, before, word, after) {
    changes++;
    return before + '<span class="' + classes[curpat] + '">' + word + '</span>' + after;
    }

    function highlight(s) {
    s = " " + s;
    for (curpat = 0; curpat < patterns.length; curpat++) {
        s = s.replace(patterns[curpat],
            repmatch);
    }
    return s.substring(1);
    }

    //    We only modify HTML/XHTML documents
    if (document.contentType &&
        (!(document.contentType.match(/html/i)))) {
        return;
    }

    // Highlight words in body copy

    var textnodes = document.evaluate("//body//text()", document, null,
        XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);

    for (var i = 0; i < textnodes.snapshotLength; i++) {
    var node = textnodes.snapshotItem(i);
    /* Test whether this text node appears within a
       <style>, <script>, or <textarea> container.
       If so, it is not actual body text and must
       be left alone to avoid wrecking the page. */
    if (node.parentNode.tagName != "STYLE" &&
        node.parentNode.tagName != "TEXTAREA" &&
        node.parentNode.tagName != "SCRIPT") {
        /* Many documents have large numbers of empty text nodes.
           By testing for them, we avoid running all of our
           regular expressions over a target which they can't
           possibly match. */
        if (!(node.data.match(/^\s*$/))) {
        var s = " " + node.data + " ";
        changes = 0;
        var d = highlight(quoteHTML(s));
        if (changes > 0) {
            var rep = document.createElement("span");
            rep.innerHTML = d.substring(1, d.length - 1);
            node.parentNode.replaceChild(rep, node);
        }
        }
    }
    }

})();

(function() {
    'use strict';

    // Your code here...
})();