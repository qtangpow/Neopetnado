// ==UserScript==
// @name         Magical Bookshop Restocker
// @namespace    Magical Bookshop
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.neopets.com/objects.phtml?type=shop&obj_type=7
// @match        http://www.neopets.com/objects.phtml?obj_type=7&type=shop
// @grant        none
// ==/UserScript==
(function() {

    var patterns = [], classes = [];

    /*    The following define the classes of words.  If the first
    character of the specification is "=", the match will be
    case-sensitive, otherwise it will be case-insensitive.
    The specification is a regular expression, and should
    contain metacharacters to handle variant spellings and
    plurals.  Any grouping within these patterns *must* be done
    with a (?: ... ) specification to avoid messing up the
    capture from the text string.

    You may add additional categories as you wish, but be sure to
    declare their rendering in the style definition below.  */

    //    Rendering styles for our various word classes

    addGlobalStyle('span.blue { background-color: #00CCFF; } ' +
           'span.silver { background-color: #A4A4A4; } ' +
           'span.gold { background-color: #FE9A2E; } ');

    //    MSM "blue" words

    defwords([
"101 Beverage Recipes",
"101 Snowman Jokes",
"300m Peanut Dash Guide Book",
"A Beginners Guide to Mixing Transmogrification Potions",
"A Faerie Beautiful Day",
"A Snowbunny Tail",
"A Summer of Borovan",
"Abominable Snowball Fights",
"Advert Attack Guide Book",
"Aisha Lovin It",
"All About Earth Faeries",
"Altador Altador Cup Media Book",
"Altador Cup Magazine",
"Altador Cup Rule Book",
"Altador Paperback Book",
"An Elderly Acaras Day Off",
"An Eyrie Evening",
"Angelic Usukis",
"Attack Of The Meercabots",
"Better Than You",
"Biological Encyclopedia of 14 Basic Neopian Algaes Vol. 12",
"Book of Evil Schemes",
"Brightvale Altador Cup Media Book",
"Calendar Scroll",
"Carnival Of Terror Guide Book",
"Catalogue of Secret Paint Brushes",
"Chocolate Chia Cookbook",
"Common Cures",
"Concert Hall Pictures",
"Cooking With Peas",
"Crypt Days",
"Cybunny Secrets",
"Decorative Towel Folding",
"Defence in the Battledome",
"Desert Days",
"Do It Yourself Bobbleheads",
"Dont Call Me Cute",
"Double Tuskaninny Tales",
"Draik Magic",
"Enchanted Butterfly Book",
"Experimental Physics",
"Eye Of The Grarrl",
"Faerie Usukis",
"Faerieland Altador Cup Media Book",
"Faeries of Spring",
"Faeries of Winter",
"Famous Aisha Magicians",
"Famous Chias",
"Feepit Pop-Up Book",
"Flotsam Wok Recipes",
"Friends Forever",
"Gelert A to Z",
"Gloating Grand Bogen",
"Grand Master",
"Grundo Cafe Recipes",
"Hand-crafted Wool Paper",
"Happy Feet",
"Harquins Day",
"Haunted Woods Altador Cup Media Book",
"Hiding Valuables",
"History of the Strength Potion",
"Hot Dog Recipes",
"How to make Origami Creatures",
"Hunting The Meerca Way",
"I Love Moo-cee",
"I, Moehog",
"Illusens Book of Charm",
"Infamous Xweetok Guide",
"Ixi Glade",
"Jeran the Lupe",
"JubJub Day Ideas",
"JubJub Journal",
"Just Rolling Along",
"Kacheek Magic",
"Kiko Lake Altador Cup Media Book",
"Kiko: Emperor of the Desert",
"Korbats Lab Secrets",
"Lawyerbot Poetry Vol. 1",
"Legend of the Alabriss",
"Little Timmys Story",
"Long Neck Lucy",
"Lost Desert Altador Cup Media Book",
"Lost Spells of Neopia",
"Making Kau Plushies",
"Maraqua Altador Cup Media Book",
"Maraquan Pop-Up Book",
"Meridell Altador Cup Media Book",
"Moehug Visits Altador",
"Mollusk Magazine",
"My Hobby Book",
"Mynci Book of World Records",
"Mystery Island Altador Cup Media Book",
"Neopian Autumns",
"Noodles for ALL",
"Nutty The Turdle",
"On Tour with Chomby and the Fungus Balls",
"Patter Feet",
"Poogle Performers",
"Potgatkerchis Protection",
"Pteri Poetry",
"Rare Stamps",
"Rare and Retired Items",
"Roo Island Altador Cup Media Book",
"Scents Of The Skeith",
"Scorchio Defence",
"Secret Bruce Journal",
"Shadow Usul Stories",
"Shenkuu Altador Cup Media Book",
"Shenkuu Floral Arrangement",
"Spring Soiree",
"Tales of Autumn",
"Talk Like A Pirate",
"Terror Mountain Altador Cup Media Book",
"The Best of Neopian Ice",
"The Chomby Champion",
"The Chomby Secret",
"The Dark Peophin",
"The Draik",
"The Guide to Facial Hair",
"The Hot Scorchio Cook Book",
"The Korbat Researcher",
"The Loneliest Draik",
"The Lonely JubJub",
"The Lost Grundo",
"The Midnight Moehog",
"The Pineapple Chia",
"The Plushie Skeith",
"The Red Paw",
"The Sneaky Schnelly",
"The Spectre Legacy",
"The Spotted Flotsam",
"The Story of the Acara Acrobat",
"The Ultimate Sticker Book",
"To Beak or Not to Beak",
"Toast Tasting",
"Treelurkers",
"Twisted Tales Of The Mutant Ruki",
"Tyrannia Altador Cup Media Book",
"Uni Cycles",
"Uni and the Uniocto",
"Unleashed - The Great Lupe Escape",
"Unwanted Grey",
"Usul Health",
"Usul Investigations",
"Vicious Attack Book",
"Viras Revenge",
"Virtupets Altador Cup Media Book",
"Volcano Run Game Guide",
"What Me Cheat",
"Wings Over the World",
"Wings of Steel",
"Wings of a Ghost",
"Wocky Magic",
"Writers Tips",
"Zap the Robot Aisha",
"Zombie Legends",


                ],
    "blue");

    //    MSM "silver" words

    defwords([
"Cenanit Ragamans",
"Cheat By Capara",
"Chianatomy",
"Cleaning Technology",
"Cooking With Your Wock(y)",
"Darigan Citadel Altador Cup Media Book",
"Deciphering Your Dreams",
"Draik Tales",
"Faeries from Paradise",
"Forbidden Pteri Tales",
"Gallery Of Toast",
"Go Home Moehog!",
"Growing a Vine Yard",
"Hold Your Breath",
"How to Make a Bonfire",
"Illusens Journey",
"Illusions Illusion",
"Jazzmosis Biography",
"Krawk Island Altador Cup Play Book",
"Legend Of The Quiggle Runner",
"Lupe Digest",
"Lupe Legends",
"Meercas In Love",
"Meruth The True Story",
"Moehog Masterpieces",
"Monstrous Makeovers",
"Mortog Music",
"Neopian Atlas",
"Neopias Past",
"Peophin Power!",
"Poogle Day Ideas",
"Poogle Pages",
"Professor Hugo Fairweathers Guide to Petpetpets",
"Purple Lupe Photo Album",
"Quantum Physics",
"Rubber Mallard Collecting",
"Secret Lenny Book",
"Shenkuu Hiking",
"Spotting Seaweed",
"Super Lupe Comics",
"The Draconian Scroll",
"The Eyrie Guard",
"The Grizzly Gruslen",
"The Joys of Cooking with Magma",
"The Legend of Scordrax",
"The Pea From Outer Space",
"The Velveteen Draik",
"The Way of the Draik",
"Unabridged Dictionary",
"Zafara War",

         ],
    "silver");
    
        //    MSM "gold" words
    
    defwords([
"A Chia Halloween",
"A Chia Story",
"A History of Chias",
"A Seasonal Pea",
"Aerial Shots of Neopia",
"Baking Chocolate Korbats",
"Beating Sloth",
"Best Friends",
"Book Of Peas",
"Book of Fake Scratchcards",
"Brain Trees Brainiac",
"Bruces Guide to Combat Eating",
"Cake Recipes for All Occasions",
"Calculus Basics",
"Chia Art History",
"Chia Quotes",
"Chomby Mysteries",
"Chomby Poems",
"Conquer the Dark",
"Cures for Bad Breath",
"Cybunny Care",
"Decoding a Coded Decoding Book",
"Extinct Neopian Languages",
"Faerie Chombies",
"Faerie Imprisonment for Fun and Profit",
"Faerie Secrets",
"Forbidden Zafara",
"Gifts for your Enemies",
"Grundo Tales",
"Gruslens Galore",
"Illusens Diary",
"Inside the Mind of Bob",
"Iron Skeith",
"Joy of Jelly Kaus",
"Kau Pastures",
"Kougra Classics",
"Koya Korbat Huntress",
"Lenny Cookbook",
"Lenny Witchcraft",
"Modern Lupe Magazine",
"Moehog Matching",
"My Life As A Lenny",
"Neopian Heroes",
"Nimmo Battle Cry",
"Olde Zafara",
"Petfolio",
"Princess Vyssas Diary",
"Pteri Pop-Up Book",
"Radio Active Pteri Part 2",
"Sophie, A Biography",
"Space and Magic",
"Spooky Usul Stories",
"Super Secret Guide to the Defenders of Neopia Headquarters",
"The Bad Skeith",
"The Book of Paper Cuts",
"The Happiest Day",
"The Island Of Kacheeks",
"The Key to being an Altadorian",
"The Life of a Hot Dog",
"The Magic Staff",
"The Shadow Usul",
"The Voodoo Techo",
"The Zombie Chomby",
"Trigonometry Hyperbolics",
"Ultimate Space Chronicles Set",
"Uni Myths",
"Zafara Lore",
"Zafara Mystery Collection",

         ],
    "gold");

    //    Add one or more words to the dictionary with a specified class

    function defwords(words, which_class) {
    for (var i = 0; i < words.length; i++) {
        var w = words[i].replace(/^=/, "");
        patterns.push(new RegExp("([^a-zA-Z])(" + w + ")([^a-zA-Z])",
        words[i].match(/^=/) ? "g" : "gi"));
        classes.push(which_class);
    }
    }

    //    Quote HTML metacharacters in body text

    function quoteHTML(s) {
    s = s.replace(/&/g, "&amp;");
    s = s.replace(/</g, "&lt;");
    s = s.replace(/>/g, "&gt;");
    return s;
    }

    //    Add one or more CSS style rules to the document

    function addGlobalStyle(css) {
    var head, style;
    head = document.getElementsByTagName('head')[0];
    if (!head) {
        return;
    }
    style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = css;
    head.appendChild(style);
    }

    //    Apply highlighting replacements to a text sequence

    var curpat;             // Hidden argument to repmatch()
    var changes;            // Number of changes made by repmatch()

    function repmatch(matched, before, word, after) {
    changes++;
    return before + '<span class="' + classes[curpat] + '">' + word + '</span>' + after;
    }

    function highlight(s) {
    s = " " + s;
    for (curpat = 0; curpat < patterns.length; curpat++) {
        s = s.replace(patterns[curpat],
            repmatch);
    }
    return s.substring(1);
    }

    //    We only modify HTML/XHTML documents
    if (document.contentType &&
        (!(document.contentType.match(/html/i)))) {
        return;
    }

    // Highlight words in body copy

    var textnodes = document.evaluate("//body//text()", document, null,
        XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);

    for (var i = 0; i < textnodes.snapshotLength; i++) {
    var node = textnodes.snapshotItem(i);
    /* Test whether this text node appears within a
       <style>, <script>, or <textarea> container.
       If so, it is not actual body text and must
       be left alone to avoid wrecking the page. */
    if (node.parentNode.tagName != "STYLE" &&
        node.parentNode.tagName != "TEXTAREA" &&
        node.parentNode.tagName != "SCRIPT") {
        /* Many documents have large numbers of empty text nodes.
           By testing for them, we avoid running all of our
           regular expressions over a target which they can't
           possibly match. */
        if (!(node.data.match(/^\s*$/))) {
        var s = " " + node.data + " ";
        changes = 0;
        var d = highlight(quoteHTML(s));
        if (changes > 0) {
            var rep = document.createElement("span");
            rep.innerHTML = d.substring(1, d.length - 1);
            node.parentNode.replaceChild(rep, node);
        }
        }
    }
    }

})();

(function() {
    'use strict';

    // Your code here...
})();